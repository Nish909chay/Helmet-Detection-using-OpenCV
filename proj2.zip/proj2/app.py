from flask import Flask, render_template, request, redirect, url_for
import os
from datetime import datetime
import numpy as np
import mysql.connector
import plotly.graph_objs as go

app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER



@app.route('/')
def index():
    data = fetch_data()
    #return render_template('main_page.html', data=data)
    return render_template('main_page.html')

@app.route('/dashboard')
def dashboard():
    uploaded_files = get_uploaded_files_with_index()
    return render_template('dashboard.html', uploaded_files=uploaded_files)

def get_uploaded_files_with_index():
    uploaded_files = get_uploaded_files()
    return [(index + 1, file) for index, file in enumerate(uploaded_files)]

@app.route('/settings')
def settings():
    return render_template('settings.html')

@app.route('/history')
def history():
    # Logic for history page goes here
    return render_template('history.html')

@app.route('/themes')
def themes():
    # Logic for themes page goes here
    return render_template('themes.html')

@app.route('/graph')
def graph():
    x, y = generate_sample_data()
    graph_data = create_plotly_graph(x, y)
    return render_template('graph.html', graph_data=graph_data)

def generate_sample_data():
    x = np.linspace(0, 10, 100)
    y = np.sin(x)
    return x, y

def create_plotly_graph(x, y):
    trace = go.Scatter(x=x, y=y, mode='lines', name='Sample Data')
    layout = go.Layout(title='Sample Graph', xaxis=dict(title='X-axis Label'), yaxis=dict(title='Y-axis Label'))
    graph_data = go.Figure(data=[trace], layout=layout)
    return graph_data.to_html(full_html=False)

@app.route('/upload', methods=['POST'])
def upload_file():
    if request.method == 'POST':
        file = request.files['file']
        if file:
            filename = file.filename
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)
            current_datetime = datetime.now()
            date = current_datetime.strftime('%Y-%m-%d')
            time = current_datetime.strftime('%H:%M:%S')
            timestamp = current_datetime.timestamp()
            uploaded_files = get_uploaded_files()
            uploaded_files.append({
                'filename': filename,
                'file_path': file_path,
                'date': date,
                'time': time,
                'timestamp': timestamp
            })
    return redirect(url_for('dashboard'))

def get_uploaded_files():
    uploaded_files = []
    for filename in os.listdir(app.config['UPLOAD_FOLDER']):
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        date, time, timestamp = get_file_details(file_path)
        uploaded_files.append({
            'filename': filename,
            'file_path': file_path,
            'date': date,
            'time': time,
            'timestamp': timestamp
        })
    return uploaded_files

def get_file_details(file_path):
    timestamp = os.path.getmtime(file_path)
    datetime_object = datetime.fromtimestamp(timestamp)
    date = datetime_object.strftime('%Y-%m-%d')
    time = datetime_object.strftime('%H:%M:%S')
    return date, time, timestamp

if __name__ == '__main__':
    app.run(debug=True)
